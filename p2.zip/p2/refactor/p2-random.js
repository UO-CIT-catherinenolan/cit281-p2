/*
    CIT 281 Project 2
    Name: Catherine Nolan
*/


// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}


//include alphabet constant from above
//function getRandomLetter will return a single random letter from the array constant alphabet

function getRandomLetter () {
    const alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
    return alphabet[getRandomInteger(0, alphabet.length)];
}

//will return random string length by using getRandomLetter and new parameters
 function getRandomString (minLength, maxLength) {
    let result = "";
    let lengthOfOutputString = getRandomInteger(minLength, maxLength + 1);
    for (let i = 0; i < lengthOfOutputString; i++) {
    result += getRandomLetter(); 
    }
    return result; 
 }

 //function will return a string in ascending order
 function getSortedString (string) {
    return string.split("").sort().join(""); 
 }


 console.log(getSortedString(getRandomString(10, 20))); 